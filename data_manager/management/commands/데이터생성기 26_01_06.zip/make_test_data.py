import sqlite3
import random
from datetime import datetime
from django.core.management.base import BaseCommand
from django.conf import settings

class Command(BaseCommand):
    help = '상품을 제외한 유저, 카테고리 및 행동 테스트 데이터를 생성합니다.'

    def handle(self, *args, **options):
        # 0. 경로 설정 (settings.py 설정을 따르거나 직접 지정)
        # settings.BASE_DIR.parent / 'project.db' 구조를 활용합니다.
        db_path = str(settings.BASE_DIR.parent / 'project.db')
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        self.stdout.write("--- Bg_Product를 제외한 나머지 테이블 초기화 중 ---")
        
        # Bg_Product를 제외한 초기화 리스트
        tables = [
            'Bg_User', 'Bg_Cart', 'Bg_Wishlist', 'Bg_Recent_product', 
            'Bg_Review', 'Bg_Order', 'Bg_Order_item', 'Bg_Interest_category', 
            'Bg_Category_product_mapping', 'Bg_User_category_mapping', 'Bg_AI_recommendation'
        ]
        
        for table in tables:
            try:
                cursor.execute(f"DELETE FROM {table}")
                cursor.execute(f"DELETE FROM sqlite_sequence WHERE name='{table}'")
            except: pass

        # 1. 상세 카테고리 생성
        category_names = [
            "뷰티/피부 케어", "바디/운동", "건강 관리", "식습관/식단", "정신/웰니스",
            "미백/톤업", "수분/촉촉", "탄력/동안", "붓기 완화", "근육 생성"
        ]
        
        cats = [(i, name, None, 1) for i, name in enumerate(category_names, 1)]
        cursor.executemany("INSERT INTO Bg_Interest_category (id, category_name, parent_id, depth) VALUES (?,?,?,?)", cats)

        # 2. 유저 생성 (100명)
        users = []
        for i in range(1, 101):
            users.append((i, f'user{i}', '1234', f'테스터{i}', f'010-0000-{i:04d}', f'u{i}@test.com', 'USER'))
        cursor.executemany(
            "INSERT INTO Bg_User (id, login_id, password, user_name, phone, email, role) VALUES (?,?,?,?,?,?,?)", 
            users
        )

        # ---------------------------------------------------------
        # [삭제됨] 3. 상품 생성 로직 (insert_fruits.py에서 처리함)
        # ---------------------------------------------------------

        # 3. 상품-카테고리 매핑 (현재 DB에 있는 237개의 상품 기준)
        # Bg_Product에 데이터가 먼저 들어있어야 작동합니다.
        prod_cat_map = []
        for p_id in range(1, 238): # Fruits-360 데이터 개수 237개에 맞춤
            chosen = random.sample(range(1, len(category_names) + 1), random.randint(1, 3))
            for c_id in chosen:
                prod_cat_map.append((p_id, c_id))
        cursor.executemany("INSERT INTO Bg_Category_product_mapping (product_id, interest_category_id) VALUES (?,?)", prod_cat_map)

        # 4. 유저 관심사 매핑
        user_int_map = []
        for u_id in range(1, 101):
            chosen = random.sample(range(1, len(category_names) + 1), random.randint(2, 5))
            for c_id in chosen:
                user_int_map.append((u_id, c_id))
        cursor.executemany("INSERT INTO Bg_User_category_mapping (user_id, interest_category_id) VALUES (?,?)", user_int_map)

        # 5. 행동 데이터 생성
        wish_data, cart_data, recent_data, review_data, orders, order_items = [], [], [], [], [], []
        o_id, oi_id = 1, 1
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        for u_id in range(1, 101):
            # 237개 상품 범위 내에서 랜덤 샘플링
            target_products = random.sample(range(1, 238), 15)
            
            for p_id in target_products:
                prob = random.random()
                recent_data.append((u_id, p_id))
                
                if prob < 0.6: # 찜
                    wish_data.append((u_id, p_id))
                if prob < 0.4: # 장바구니
                    cart_data.append((u_id, p_id, 1))
                if prob < 0.3: # 리뷰 및 주문
                    rating = round(random.uniform(3.0, 5.0), 2)
                    review_data.append((u_id, p_id, "과일이 정말 신선해요!", rating))
                    orders.append((o_id, u_id, 1, 'COMPLETED', 'CARD', 'PAID', 15000, now_str))
                    order_items.append((oi_id, o_id, p_id, 1, 15000))
                    o_id += 1
                    oi_id += 1

        # 일괄 삽입
        cursor.executemany("INSERT INTO Bg_Wishlist (user_id, product_id) VALUES (?, ?)", wish_data)
        cursor.executemany("INSERT INTO Bg_Cart (user_id, product_id, quantity) VALUES (?, ?, ?)", cart_data)
        cursor.executemany("INSERT INTO Bg_Recent_product (user_id, product_id) VALUES (?, ?)", recent_data)
        cursor.executemany("INSERT INTO Bg_Review (user_id, product_id, content, rating) VALUES (?, ?, ?, ?)", review_data)
        cursor.executemany("INSERT INTO Bg_Order (id, user_id, address_id, order_status, payment_method, payment_status, payment_price, created_at) VALUES (?,?,?,?,?,?,?,?)", orders)
        cursor.executemany("INSERT INTO Bg_Order_item (id, order_id, product_id, amount, price) VALUES (?, ?, ?, ?, ?)", order_items)

        conn.commit()
        conn.close()
        self.stdout.write(self.style.SUCCESS("--- 유저 및 행동 데이터 생성 완료! ---"))